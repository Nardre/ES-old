#!/bin/python3

# import
import pygame
from pygame.locals import *
from menu import *
from mission import *
from carte import *
from pnj import *
from joueur import *
from bouton import *
from barre import *

# initialisation
height, width = 960, 960

# fenetre
pygame.init()
fenetre = pygame.display.set_mode((height, width))
pygame.display.set_caption('ES')


#auto
AUTOFPS = USEREVENT + 1
pygame.time.set_timer(AUTOFPS, 32)

#Déplacement maintenue
pygame.key.set_repeat(30, 30)


# scene
scene = Menu(fenetre)

# joueur 
joueur = Joueur("joueur.xcf", (1, 1), fenetre)

# carte
carte0 = Carte("carte0.txt", fenetre)
carte1 = Carte("carte1.txt", fenetre)
carte2 = Carte("carte2.txt", fenetre)

# case
case0 = Bouton("case.xcf", (32*2, 32*25), (32, 32), fenetre, ["case.xcf", "case1.xcf"], -1)
arbre = Pnj("arbre.xcf", (23, 1), ["Les arbres", "diminuent le CO2"], fenetre, fois=(15, 20, 1, 6), interaction=[15, 1, 160, 160])

case1 = Bouton("case.xcf", (32*2, 32*27), (32, 32), fenetre, ["case.xcf", "case1.xcf"], 2)
champs = Pnj("champs.xcf", (25, 1), ["les champs prennent beaucoup de place", "et cause les déforestations"], fenetre, fois=(13, 21, 0, 8), interaction=[13, 0, 256, 256])

case2 = Bouton("case.xcf", (32*5, 32*25), (32, 32), fenetre, ["case.xcf", "case1.xcf"], 1)
ville1 = Pnj("ville.xcf", (23, 4), [""], fenetre, fois=(11, 12, 22, 23), interaction=[11, 22, 160, 160])
ville0 = Pnj("ville.xcf", (23, 4), ["les villes", "augmentent le CO2"], fenetre, fois=(11, 12, 8, 9), interaction=[11, 8, 160, 160])

case3 = Bouton("case.xcf", (32*11, 32*25), (32, 32), fenetre, ["case.xcf", "case1.xcf"], 2)
route = Pnj("route.xcf", (99, 99), "", fenetre, fois=(13, 14, 13, 14), interaction=[13, 13, 320, 320])
voiture0 = Pnj("voiture.xcf", (23, 10), [""], fenetre, fois=(13, 14, 13, 14), interaction=[8, 7, 32, 32])
voiture1 = Pnj("voiture.xcf", (23, 10), ["les voitures", "augmentent le CO2"], fenetre, fois=(15, 16, 18, 19), interaction=[15, 18, 32, 32])

case4 = Bouton("case.xcf", (32*11, 32*27), (32, 32), fenetre, ["case.xcf", "case1.xcf"], 1)
bus = Pnj("bus.xcf", (25, 10), ["les bus utilisent", "moins de CO2 que", "les voitures"], fenetre, fois=(13, 14, 15, 16), interaction=[13, 15, 32, 32])

case5 = Bouton("case.xcf", (32*14, 32*25), (32, 32), fenetre, ["case.xcf", "case1.xcf"], -2)
tri = Pnj("tri.xcf", (23, 13), ["le tri", "permet de ne pas", "jeter des objets ", "et diminue", "l'empreinte carbonne"], fenetre, fois=(11, 12, 26, 27), interaction=[11, 26, 32, 32])

listCase = [case0, case1, case2, case3, case4, case5]
boutonListMission0 = [(case0, [arbre]), 
					  (case1, [champs]), 
					  (case2, [route, ville1, ville0]), 
					  (case3, [voiture0, voiture1]), 
					  (case4, [bus]), 
					  (case5, [tri])]



# pnj
# pnj0 = Pnj("pnj0.xcf", (1, 25), "177013", fenetre)
soleil = Pnj("soleil.xcf", (-2, 23), ["","","         soleil"], fenetre, interaction=[-2, 23, 160, 160], booll=True)
barre = Pnj("barre.xcf", (-5, 0), ["","","","","","","","","","Barre de neutralité carbonne", "équilibre entre les émissions de CO2", "et leur éliminations de l'atmosphère"], fenetre, interaction=[-3, 0, 320, 320], booll=True)
temperature = Pnj("temperature.xcf", (-2, 10), ["","","","","","","","","","","Les gaz à effet de serre", "augmentent la température"], fenetre, interaction=[-1, 10, 160, 160], booll=True)
iceberg = Pnj("iceberg0.xcf", (7, 18), ["","","","","","","","plus il fait chaud", "plus les iceberg fond", "plus le niveau de l'eau augmente"], fenetre, ["iceberg0.xcf", "iceberg1.xcf"], listCase, interaction=[7, 18, 160, 160], booll=True)

decoListMission0 = [soleil, barre, temperature, iceberg]
pnjList0 = [soleil, route, ville0, ville1, barre, temperature, iceberg, arbre, champs, voiture0, voiture1, bus, tri]

pnjList1 = []
pnjList2 = []

# mission
mission0 = Mission("mission0.xcf", fenetre, carte0, pnjList0)
mission1 = Mission("mission1.xcf", fenetre, carte1, pnjList1)
mission2 = Mission("mission2.xcf", fenetre, carte2, pnjList2)

# barre
barreNeutralite = Barre(listCase, (210, 38), 10, 50, (20, 0), fenetre)
barreTemperature = Barre(listCase, (459, 68), 3, 20, (0, 5), fenetre, (255, 0, 0))

# bouton
bouton0 = Bouton("bouton0.xcf", (64, 512), (480, 160), fenetre)
bouton1 = Bouton("bouton1.xcf", (64, 666), (480, 160), fenetre)
bouton2 = Bouton("bouton2.xcf", (64, 824), (480, 160), fenetre)
boutonList = [(bouton0, mission0), (bouton1, mission1), (bouton2, mission2)]

# boucle infini
continuer = True
while continuer:
    for event in pygame.event.get():
        if scene.check() == "menu":

            if event.type == AUTOFPS:
                scene.afficheAll()
                for element in boutonList:
                    bouton = element[0]
                    bouton.afficheAll()
                pygame.display.flip()

            #souris
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    for element in boutonList:
                        bouton, mission = element
                        if bouton.clique(event.pos):
                            scene = mission

        if scene.check() == "mission0.xcf":
            if event.type == AUTOFPS:
                scene.afficheAll()
                for element in boutonListMission0:
                    bouton = element[0]
                    bouton.afficheAll()
                # joueur.afficheAll()
                barreNeutralite.afficheAll()
                barreTemperature.afficheAll()

                pygame.display.flip()

            #souris
            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    for element in boutonListMission0:
                        bouton, listEntite = element
                        if bouton.clique(event.pos):
                           for entite in listEntite:
                                entite.switch()
                           bouton.switch() 
                
                if event.button == 3:
                    for element in decoListMission0:
                        element.interact(event.pos)

                    for element in boutonListMission0:
                        bouton, listEntite = element
                        if bouton.getBool()[0]:
                            for entite in listEntite:
                                entite.interact(event.pos)

                
                    


            # keyboard
            if event.type == KEYDOWN :
                if event.key == K_ESCAPE:
                    scene = Menu(fenetre)
                    joueur.reset()
                """
                if event.key == K_SPACE:
                    for pnj in scene.pnjList:
                        pnj.interact(joueur.getPos())

                xJoueur, yJoueur = joueur.getPos()
                if event.key == K_UP:
                    if scene.carte.estLibre((xJoueur, yJoueur-1)):
                        joueur.deplacement(0, -1)
                if event.key == K_DOWN:
                    if scene.carte.estLibre((xJoueur, yJoueur+1)):
                        joueur.deplacement(0, 1)
                if event.key == K_LEFT:
                    if scene.carte.estLibre((xJoueur-1, yJoueur)):
                        joueur.deplacement(-1, 0)
                if event.key == K_RIGHT:
                    if scene.carte.estLibre((xJoueur+1, yJoueur)):
                        joueur.deplacement(1, 0)
            """

        if scene.check() == "mission1.xcf":
            if event.type == AUTOFPS:
                scene.afficheAll()
                pygame.display.flip()

            # keyboard
            if event.type == KEYDOWN :
                if event.key == K_ESCAPE:
                    scene = Menu(fenetre)
                    joueur.reset()

        if scene.check() == "mission2.xcf":
            if event.type == AUTOFPS:
                scene.afficheAll()
                pygame.display.flip()

            # keyboard
            if event.type == KEYDOWN :
                if event.key == K_ESCAPE:
                    scene = Menu(fenetre)
                    joueur.reset()


