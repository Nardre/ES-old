#!/bin/python3

print("X"*26)
for i in range(24):
    print("X"+" "*24+"X")
print("X"*26)
